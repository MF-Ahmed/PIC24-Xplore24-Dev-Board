#include "StdAfx.h"
#include "bootloader.h"

bootloader::bootloader(void)
{



}
