/**********************************************************************
* � 2005 Microchip Technology Inc.
*
* FileName:        uart1Drv.c
* Dependencies:    Header (.h) files if applicable, see below
* Processor:       dsPIC33Fxxxx/PIC24Hxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
* Tested On:	   dsPIC33FJ256GP710
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip's
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP'S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* RK	          04/04/06 	  First release of source file
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
**********************************************************************/
#if defined(__dsPIC33F__)
#include "p33Fxxxx.h"
#elif defined(__PIC24H__)
#include "p24Hxxxx.h"
#endif

#define FCY      40000000
#define BAUDRATE 9600                
#define BRGVAL   ((FCY/BAUDRATE)/16)-1 

void ProcessUartRxSamples(unsigned int * UartRxBuffer);

unsigned int uart1RxBuffA[16] __attribute__((space(dma)));
unsigned int uart1RxBuffB[16] __attribute__((space(dma)));
unsigned int uart1TxBuffA[16] __attribute__((space(dma)));
unsigned int uart1TxBuffB[16] __attribute__((space(dma)));

// DMA0 configuration
// Direction: Read from DMA RAM and write to UART1 Transmit register
// AMODE: Register Indirect with Post-Increment mode
// MODE: Continuous, Ping-Pong Enabled
// IRQ: UART1 TX
void cfgDma0UartTx(void)
{
	
	DMA0CON = 0x2002;					
	DMA0CNT = 15;						
	DMA0REQ = 0x00C;					

	DMA0PAD = (volatile unsigned int) &U1TXREG;
	DMA0STA= __builtin_dmaoffset(uart1TxBuffA);
	DMA0STB= __builtin_dmaoffset(uart1TxBuffB);
	
	
	IFS0bits.DMA0IF  = 0;			// Clear DMA interrupt
	IEC0bits.DMA0IE  = 1;			// Enable DMA interrupt
	DMA0CONbits.CHEN = 1;			// Enable DMA Channel	
	    
}

// DMA1 configuration
// Direction: Read from UART1 Receive Register and write to DMA RAM 
// AMODE: Register Indirect with Post-Increment mode
// MODE: Continuous, Ping-Pong Enabled
// IRQ: UART1 RX
void cfgDma1UartRx(void)
{

	DMA1CON = 0x0002;				
	DMA1CNT = 15;						
	DMA1REQ = 0x00B;					

	DMA1PAD = (volatile unsigned int) &U1RXREG;
	DMA1STA= __builtin_dmaoffset(uart1RxBuffA);
	DMA1STB= __builtin_dmaoffset(uart1RxBuffB);
	
	
	IFS0bits.DMA1IF  = 0;			// Clear DMA interrupt
	IEC0bits.DMA1IE  = 1;			// Enable DMA interrupt
	DMA1CONbits.CHEN = 1;			// Enable DMA Channel		
}


// UART1 Configuration
void cfgUart1(void)
{
// Enable Loop Back Mode
    	U1MODEbits.LPBACK  = 1;         
	
// �	Configure U2BRG register for 57600 bit rate, note Fcy=30Mhz (U2BRG=?)
//  	U1BRD=((FCY/BAUDRATE)/16)-1 
		U1BRG=BRGVAL;

// Configure U1MODE register to the following
// �	No Parity and 8-bit data (U1MODEbits.PDSEL=?)
// �	1-Stop Bit (U1MODEbits.STSEL=?)
// �	Enable UART (U1MODEbits.UARTEN=?)
		U1MODEbits.PDSEL=0;		
		U1MODEbits.STSEL=0;
		U1MODEbits.UARTEN=1;

// Configure U2STA register to the following
// �	Interrupt on data transfer to the Transmit Shift register (U1STAbits.UTXISEL=?)
// �	Interrupt on data transfer to the Receive register (U1STAbits.URXISEL=?)
// �	Enable UART Transmit Module (U2STAbits.UTXEN=?)
		U1STAbits.UTXISEL0=0;
		U1STAbits.UTXISEL1=0;		
		U1STAbits.URXISEL =0;		
		U1STAbits.UTXEN=1;		

}


/*=============================================================================
initUartBuff(): Initialise UART Buffer
==============================================================================*/
void initUartBuff(void)
{
unsigned int i;
    for(i=0;i<16;i++)
        uart1TxBuffA[i]=i;
    for(i=0;i<16;i++)
        uart1TxBuffB[i]=16+i;        
        
   	for(i=0;i<16;i++){
        uart1RxBuffA[i]=0xDEED;
        uart1RxBuffB[i]=0xDEED;
		}	
}



/*=============================================================================
Interrupt Service Routines.
=============================================================================*/
unsigned int RxDmaBuffer = 0;

void __attribute__((interrupt, no_auto_psv)) _DMA0Interrupt(void)
{

        IFS0bits.DMA0IF = 0;		//Clear the DMA0 Interrupt Flag;
}


void __attribute__((interrupt, no_auto_psv)) _DMA1Interrupt(void)
{
	if(RxDmaBuffer == 0)
	{
		ProcessUartRxSamples(&uart1RxBuffA[0]);

	}
	else
	{
		ProcessUartRxSamples(&uart1RxBuffB[0]);
	}

	RxDmaBuffer ^= 1;
	
    IFS0bits.DMA1IF = 0;		// Clear the DMA0 Interrupt Flag
}

void ProcessUartRxSamples(unsigned int * UartRxBuffer)
{
	/* Do something with SPI Samples */
}


